package com.xiaoshu.dao;

import com.xiaoshu.base.dao.BaseMapper;
import com.xiaoshu.entity.Attachment;

public interface AttachmentMapper extends BaseMapper<Attachment> {
}